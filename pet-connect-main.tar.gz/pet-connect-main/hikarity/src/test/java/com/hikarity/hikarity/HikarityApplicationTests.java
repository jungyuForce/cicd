package com.hikarity.hikarity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HikarityApplicationTests {

	@Test
	void contextLoads() {
	}

}
