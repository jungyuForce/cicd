package com.hikarity.hikarity.service;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.hikarity.hikarity.DTO.Adoption;
import com.hikarity.hikarity.mapper.HikarityMapper;

@Service
public class UserService {
    @Autowired
    private HikarityMapper mapper;

    public List<Map<String, Object>> getAll() {
        return mapper.getAll();
    }

    // public PagingResponse<PostResponse> findAllPost();

    public Map<String, Object> getDetailedAnimal(String Idx) {
        return mapper.getDetailedAnimal(Idx);
    }

    public Map<String, Object> test() {
        return mapper.test();
    }

    public void insertAdoption(Adoption dto) {
        mapper.insertAdoption(dto);
    }
    
}
