package com.hikarity.hikarity.config.database;

public class Datasource {
    
}
