package com.hikarity.hikarity.DTO;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class Adoption {
    private int userId; // 사용자 ID
    private int petIdx; // 반려동물 ID
    private String name;
    private String cellphone;
    private String address1;
    private String address2;
    private String email;
    private int employmentStatus;
    private String company;
    private String adoptionMotive;
    private String aloneOrNot;
    private String animalHospitalName;
    private String animalHospitalPhone;
    private String animalHospitalAddress;
    private int animalHospitalRecommendationYN;
    private String experience;
    private int familyAdultNum;
    private int familyChildNum;
    private int childYN;
    private int childAge;
    private int childVisit;
    private String childVisitPeriod;
    private String status; // 입양 상태
    private Date adoptionDate; // 입양 날짜

    public int getUserId() {
        return userId;
    }
    public void setUserId(int userId) {
        this.userId = userId;
    }
    public int getPetIdx() {
        return petIdx;
    }
    public void setPetIdx(int petIdx) {
        this.petIdx = petIdx;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getCellphone() {
        return cellphone;
    }
    public void setCellphone(String cellphone) {
        this.cellphone = cellphone;
    }
    public String getAddress1() {
        return address1;
    }
    public void setAddress1(String address1) {
        this.address1 = address1;
    }
    public String getAddress2() {
        return address2;
    }
    public void setAddress2(String address2) {
        this.address2 = address2;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public int getEmploymentStatus() {
        return employmentStatus;
    }
    public void setEmploymentStatus(int employmentStatus) {
        this.employmentStatus = employmentStatus;
    }
    public String getCompany() {
        return company;
    }
    public void setCompany(String company) {
        this.company = company;
    }
    public String getAdoptionMotive() {
        return adoptionMotive;
    }
    public void setAdoptionMotive(String adoptionMotive) {
        this.adoptionMotive = adoptionMotive;
    }
    public String getAloneOrNot() {
        return aloneOrNot;
    }
    public void setAloneOrNot(String aloneOrNot) {
        this.aloneOrNot = aloneOrNot;
    }
    public String getAnimalHospitalName() {
        return animalHospitalName;
    }
    public void setAnimalHospitalName(String animalHospitalName) {
        this.animalHospitalName = animalHospitalName;
    }
    public String getAnimalHospitalPhone() {
        return animalHospitalPhone;
    }
    public void setAnimalHospitalPhone(String animalHospitalPhone) {
        this.animalHospitalPhone = animalHospitalPhone;
    }
    public String getAnimalHospitalAddress() {
        return animalHospitalAddress;
    }
    public void setAnimalHospitalAddress(String animalHospitalAddress) {
        this.animalHospitalAddress = animalHospitalAddress;
    }
    public int getAnimalHospitalRecommendationYN() {
        return animalHospitalRecommendationYN;
    }
    public void setAnimalHospitalRecommendationYN(int animalHospitalRecommendationYN) {
        this.animalHospitalRecommendationYN = animalHospitalRecommendationYN;
    }
    public String getExperience() {
        return experience;
    }
    public void setExperience(String experience) {
        this.experience = experience;
    }
    public int getFamilyAdultNum() {
        return familyAdultNum;
    }
    public void setFamilyAdultNum(int familyAdultNum) {
        this.familyAdultNum = familyAdultNum;
    }
    public int getFamilyChildNum() {
        return familyChildNum;
    }
    public void setFamilyChildNum(int familyChildNum) {
        this.familyChildNum = familyChildNum;
    }
    public int getChildYN() {
        return childYN;
    }
    public void setChildYN(int childYN) {
        this.childYN = childYN;
    }
    public int getChildAge() {
        return childAge;
    }
    public void setChildAge(int childAge) {
        this.childAge = childAge;
    }
    public int getChildVisit() {
        return childVisit;
    }
    public void setChildVisit(int childVisit) {
        this.childVisit = childVisit;
    }
    public String getChildVisitPeriod() {
        return childVisitPeriod;
    }
    public void setChildVisitPeriod(String childVisitPeriod) {
        this.childVisitPeriod = childVisitPeriod;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public Date getAdoptionDate() {
        return adoptionDate;
    }
    public void setAdoptionDate(Date adoptionDate) {
        this.adoptionDate = adoptionDate;
    }

    // Getters and Setters
    
}
